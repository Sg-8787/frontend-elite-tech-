import React, { useState, useEffect } from "react";
import * as Ably from "ably";

const ably = new Ably.Realtime("YOUR_ABLY_API_KEY"); // Replace with your Ably API key
const channel = ably.channels.get("chat-app");

function App() {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);

  useEffect(() => {
    channel.subscribe("new-message", (msg) => {
      setChat((prev) => [...prev, msg.data]);
    });

    return () => {
      channel.unsubscribe();
    };
  }, []);

  const sendMessage = () => {
    if (message.trim() === "") return;
    channel.publish("new-message", message);
    setMessage("");
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: "auto" }}>
      <h2>💬 Real-Time Chat App</h2>
      <div style={{ border: "1px solid #ccc", height: 300, overflowY: "scroll", padding: 10 }}>
        {chat.map((msg, idx) => (
          <div key={idx} style={{ margin: 5, background: "#eee", padding: 8, borderRadius: 5 }}>{msg}</div>
        ))}
      </div>
      <div style={{ display: "flex", marginTop: 10 }}>
        <input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          style={{ flex: 1, padding: 10 }}
        />
        <button onClick={sendMessage} style={{ marginLeft: 10, padding: "10px 20px" }}>
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
